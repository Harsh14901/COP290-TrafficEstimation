#include <bits/stdc++.h>

#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;

void remove_black_borders(const Mat &src, Mat &dst);